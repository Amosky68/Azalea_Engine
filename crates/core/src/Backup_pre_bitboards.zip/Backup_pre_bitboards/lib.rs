pub mod board;
pub mod gamestate;
pub mod moves;
pub mod search;
pub mod eval;
pub mod zobrist;

pub mod gamestate2;
pub mod moves2;
pub mod BitboardsUtils;


pub fn add(left: u64, right: u64) -> u64 {
    left + right
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn it_works() {
        let result = add(2, 2);
        assert_eq!(result, 4);
    }
}
